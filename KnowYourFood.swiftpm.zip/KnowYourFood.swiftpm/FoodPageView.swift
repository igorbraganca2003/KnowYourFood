//
//  foodPageView.swift
//  KnowYourFood
//
//  Created by Igor Bragança Toledo on 18/04/23.
//
import SwiftUI
import Foundation

struct FoodPageView: View {
    var fruits: [String] = ["Avocado", "Apple", "Pinapple","Grape", "Pepper", "Cauliflower", "Pumpkin", "Brocolis"]
    var detailFruitsType: [String] = ["Calories", "Proteins", "Fats", "Carbohydrates", "Sugar"]
    var detailFruitsValues = [["5.6 oz", "0.07 oz", "0.53 oz", "0.32 oz","0.02 oz"], ["1.8 oz", "0.01 oz", "0.001 oz", "0.49 oz", "0.35 oz"], ["1.8 oz", "0.02 oz", "0.004 oz", "0.46 oz","0.35 oz"], ["2.4 oz", "0.02 oz", "0.007 oz", "0.63 oz", "0.56 oz"], ["0.63 oz", "0.03 oz", "0.001 oz", "0.14 oz", "0.08 oz"],["0.88 oz", "0.007 oz", "0.001 oz", "0.19 oz", "0.09 oz"],["1.06 oz", "0.004 oz", "0 oz", "0.26 oz", "0.11 oz"],["1.09 oz", "0.009 oz", "0.01 oz", "0.21 oz", "0.36 oz"]]
    
    var detailVegetables: [String] = []
    var colorRed: [Double] = [159, 255, 249, 206, 248,  222, 254,163]
    var colorGreen: [Double] = [215, 164, 232, 175, 126,227, 172, 195]
    var colorBlue: [Double] = [175, 161, 116, 245, 126, 121,80, 109]
    var index: Int
    
    var body: some View{
        GeometryReader { geometry in
            Color(red: colorRed[index]/255.0, green: colorGreen[index]/255.0, blue: colorBlue[index]/255.0)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .ignoresSafeArea()
            VStack(alignment: .leading){
                Text("\(fruits[index])")
                    .foregroundColor(.white)
                    .font(.system(size: 70))
                    .font(.largeTitle)
                    .bold()
                    .padding(.leading, 60)
                    .padding(.top, 20)
                Spacer()
                Image(fruits[index])
                    .resizable().scaledToFit()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width / 1, height: geometry.size.height / 2)
                Spacer()
                ZStack{
                    Rectangle()
                        .fill(Color.white)
                        .cornerRadius(80)
                        .frame(width: geometry.size.width * 1, height: geometry.size.height * 0.5)
                    VStack(alignment: .leading){
                        Text("Nutritional Information (3.5 oz):")
                            .foregroundColor(.black)
                            .font(.system(size: 40))
                            .font(.largeTitle)
                            .bold()
                            .padding(.top, 60)
                            .padding(.leading, 90)
                        NutriciousValues(nutriciousTitle: detailFruitsType, nutriciousNumbers: detailFruitsValues[index], index: index)
//                        Text("\(detailFruits[index])")
                            .foregroundColor(.black)
                            .font(.system(size: 30))
                            .padding(.top, 30)
                            .padding(.horizontal, 130)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.bottom, 20)
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
}

struct NutriciousValues: View{
    var nutriciousTitle: [String]
    var nutriciousNumbers: [String]
    var colorRed: [Double] = [59, 2155, 249, 206, 248, 222, 254,163]
    var colorGreen: [Double] = [215, 164, 232, 175, 126,227,172,195]
    var colorBlue: [Double] = [175, 161, 116, 245, 126, 121,80,109]
    var index: Int
    
    var body: some View{
        VStack{
            ForEach(0..<nutriciousTitle.count, id: \.self){ i in 
                HStack{
                    
                    Text("•")
                        .foregroundColor(Color(red: colorRed[index]/255.0, green: colorGreen[index]/255.0, blue: colorBlue[index]/255.0))
                    Text("\(nutriciousTitle[i])")
                    Spacer()
                    Text("\(nutriciousNumbers[i])")
                }
            }
        }
    }
}
