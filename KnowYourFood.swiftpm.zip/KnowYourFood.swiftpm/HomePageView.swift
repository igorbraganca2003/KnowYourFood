import SwiftUI

struct HomePageView: View {
    var name: String
    var padango_lead: CGFloat = 60
    
    var body: some View{
        GeometryReader { geometry in
            ScrollView {
            VStack(alignment: .leading){
                VStack(alignment: .leading){
                    Text("Hello")
                        .foregroundColor(.gray)
                        .font(.system(size: 40))
                        .font(.subheadline)
                        .padding(.top, 20)
                        .padding(.leading, padango_lead)
                    Text(name)
                        .foregroundColor(.black)
                        .font(.system(size: 60))
                        .font(.largeTitle)
                        .bold()
                        .padding(.leading, padango_lead)
                        .padding(.bottom, 3)
                    Text("'Welcome to my app \(name)! Here you will find a variety of healthy and nutritious foods to help you maintain a balanced diet and improve your health.'")
                        .italic()
                        .foregroundColor(.black)
                        .font(.system(size: 25))
                        .lineSpacing(5)
                        .font(.largeTitle)
                        .padding(.trailing, 60)
                        .padding(.leading, padango_lead)
                }
                VStack(alignment: .leading){
                        Text("Fruits")
                            .foregroundColor(.black)
                            .font(.system(size: 30))
                            .font(.subheadline)
                            .padding(.top, 40)
                            .padding(.leading, 60)
                        ScrollView(.horizontal, showsIndicators: false){
                            HStack{
                                
                                //Avocado
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:159/255.0, green: 215/255.0, blue: 157/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Avocado")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Avocado")
                                            .resizable().frame(width:436,height: 400)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 0)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:159/255.0, green: 215/255.0, blue: 157/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10) .padding(.bottom, 20)
                                
                                //Apple
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:255/255.0, green: 164/255.0, blue: 161/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Apple")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Apple")
                                            .resizable().frame(width:408,height: 450)
                                            .position(x: geometry.size.width / 4.5, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 1)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:255/255.0, green: 164/255.0, blue: 161/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20)
                                
                                //Pinapple
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:249/255.0, green: 232/255.0, blue: 116/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Pinapple")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Pinapple")
                                            .resizable().frame(width:400,height: 350)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 2)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:249/255.0, green: 232/255.0, blue: 116/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20)
                                
                                //Grape
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:206/255.0, green: 175/255.0, blue: 245/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Grape")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Grape")
                                            .resizable().frame(width:400,height: 300)
                                            .position(x: geometry.size.width / 4.1, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 3)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:206/255.0, green: 175/255.0, blue: 245/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20).padding(.trailing, 60)
                                
                            }
                        }
                       
                        
                    }
                
                VStack(alignment: .leading){
                        Text("Vegetables")
                            .foregroundColor(.black)
                            .font(.system(size: 30))
                            .font(.subheadline)
                            .padding(.top, 40)
                            .padding(.leading, 60)
                        ScrollView(.horizontal, showsIndicators: false){
                            HStack{
                                
                                //Pepper
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:248/255.0, green: 126/255.0, blue: 126/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Pepper")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Pepper")
                                            .resizable().frame(width:400,height: 350)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5.5)
                                        NavigationLink(destination: FoodPageView(index: 4)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:248/255.0, green: 126/255.0, blue: 126/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20)
                                
                                //cauliflower
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:222/255.0, green: 227/255.0, blue: 121/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Cauliflower")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Cauliflower")
                                            .resizable().frame(width:400,height: 400)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 5)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:222/255.0, green: 227/255.0, blue: 121/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10) .padding(.bottom, 20).padding(.leading, 15)
                                
                                //Pumpkin
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:254/255.0, green: 172/255.0, blue: 80/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Pumpkin")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Pumpkin")
                                            .resizable().frame(width:400,height: 400)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5)
                                        NavigationLink(destination: FoodPageView(index: 6)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:254/255.0, green: 172/255.0, blue: 80/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20)
                                
                                //Brocolis
                                ZStack{
                                    Rectangle()
                                        .fill(Color(red:163/255.0, green: 195/255.0, blue: 109/255.0))
                                        .cornerRadius(30)
                                        .frame(width: geometry.size.width * 0.45, height: geometry.size.height * 0.6)
                                        .shadow(color: Color.gray.opacity(0.3), radius: 5, x: 5, y: 5)
                                        .padding(.leading, 40)
                                    VStack(alignment: .leading){
                                        Text("Brocolis")
                                            .foregroundColor(.white)
                                            .font(.system(size: 45))
                                            .font(.largeTitle)
                                            .bold()
                                            .padding(.leading, 80)
                                            .padding(.top, 20)
                                        Image("Brocolis")
                                            .resizable().frame(width:430,height: 430)
                                            .position(x: geometry.size.width / 4, y: geometry.size.height / 5.5)
                                        NavigationLink(destination: FoodPageView(index: 7)) {
                                            Text("Know More!")
                                                .font(.system(size:20))
                                                .foregroundColor(Color(red:163/255.0, green: 195/255.0, blue: 109/255.0))
                                                .frame(width:270, height:60)
                                                .background(Color.white)
                                                .cornerRadius(10)
                                                .padding(.leading, 100)
                                                .padding(.bottom, 50)
                                        }
                                    }
                                }.padding(.top, 10).padding(.bottom, 20) .padding(.trailing, 60)
                                
                            }
                        }
                       
                        
                }.padding(.leading, 15)
                }

            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}
