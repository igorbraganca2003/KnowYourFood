import SwiftUI

struct ContentView: View {
    @State private var name = ""
    @State private var Sobrenome = ""
    @State private var mostrarTelaDeLogin = false
    
    var body: some View{
            GeometryReader { geometry in
                NavigationView{
                ZStack{
                    Color.orange
                        .ignoresSafeArea()
                    Rectangle()
                        .fill(Color.white)
                        .cornerRadius(60)
                        .frame(width: geometry.size.width * 1, height: geometry.size.height * 1)
                        .position(x: geometry.size.width / 2, y: geometry.size.height / 1.4)
                    Image("Orange")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geometry.size.width * 0.3)
                        .position(x: geometry.size.width / 2, y: geometry.size.height * 0.23)
                    
                    VStack{
                        Text("Welcome!")
                            .foregroundColor(.black)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.45)
                        VStack{
                            TextField("Name", text: $name)
                                .padding()
                                .frame(width:400, height: 60)
                                .foregroundColor(.black)
                                .background(Color.gray.opacity(0.3))
                                .cornerRadius(10)
                            NavigationLink(destination: HomePageView(name: name)) {
                                Text("Enter")
                                    .font(.system(size:20))
                                    .foregroundColor(.white)
                                    .frame(width:400, height:60)
                                    .background(Color.orange)
                                    .cornerRadius(10)
                            }.padding(.top, 20)
                        }.position(x: geometry.size.width / 2, y: geometry.size.height / 6)
                    }
                }.navigationBarHidden(true)
                        .navigationBarTitleDisplayMode(.inline)
                        
            }.navigationViewStyle(.stack)
                    .accentColor(.black)
        }
    }
}

